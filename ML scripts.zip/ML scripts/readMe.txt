To run ML script, all you have to do is to put the scripts in the same folder as "dataset"
You can also use gridSearch_ML.py to to tune ML parameters