to excecute the script:
1. first put them in the same folder as "dataset"
2. check that all the needed packages like Keras are already installed, otherwise read "Installations_Instructions.pdf"
3. There is a simple example in validationExperiments.py of how to run DL-CIBuild
4. There it is you can start CI build Prediction!